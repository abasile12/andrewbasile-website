---
name: viral-video-analyzer
description: Placeholder. Replace this folder with the real SKILL.md and files before shipping.
---

# viral-video-analyzer

This zip is a placeholder so the download button on andrewbasile.com works. Drop the real skill folder in /skills and re-zip.
