---
name: feed-studios-content-engine
description: Placeholder. Replace this folder with the real SKILL.md and files before shipping.
---

# feed-studios-content-engine

This zip is a placeholder so the download button on andrewbasile.com works. Drop the real skill folder in /skills and re-zip.
