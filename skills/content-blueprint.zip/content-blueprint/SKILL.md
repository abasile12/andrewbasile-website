---
name: content-blueprint
description: Placeholder. Replace this folder with the real SKILL.md and files before shipping.
---

# content-blueprint

This zip is a placeholder so the download button on andrewbasile.com works. Drop the real skill folder in /skills and re-zip.
